/*
* MCreator note: This file will be REGENERATED on each build.
*/
package net.haipadev.simplysulphur.init;

public class SimplySulphurModBrewingRecipes {
	public static void load() {
	}
}
